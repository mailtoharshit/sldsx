<aura:interface access="GLOBAL" description="Interface for page headers (aka anchors).">
	<aura:attribute name="type" type="String" access="GLOBAL" default="" description="The type of page header - record home, object home, releated list."/>
</aura:interface>