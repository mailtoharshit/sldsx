({
    init: function(component, event, helper) {
        helper.update(component);
    }
})