({
    afterRender: function(component, helper) {
        helper.setup(component);
	}
})