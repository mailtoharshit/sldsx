({
    init: function(component, event, helper) {
        //helper.init(component);
        helper.update(component);
    },
    
    update: function(component, event, helper) {
        helper.update(component);
    }
})