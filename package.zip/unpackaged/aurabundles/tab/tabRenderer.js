({
    render: function(component, helper) {
        //helper.init(component);

        var ret = this.superRender();
        
        return ret;
    }
})