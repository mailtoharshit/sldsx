({
    update: function(component, event, helper) {
        helper.update(component);
    },
    
    handlePress: function(component, event, helper) {
        console.warn("pillController.handlePress");
    }
})