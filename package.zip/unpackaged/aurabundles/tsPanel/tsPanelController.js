({
	init: function(component, event, helper) {
		component.set("v.timestamp", Date.now());
	}
})